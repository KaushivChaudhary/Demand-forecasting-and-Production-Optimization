# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 11:26:22 2024

@author: akshi
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pandas.plotting import lag_plot
from scipy.stats import skew, kurtosis
from feature_engine.outliers import Winsorizer
import scipy.stats as stats
import pylab
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
import pickle, joblib

data=pd.read_csv(r'C:\Users\varsh\Downloads\monthly_data (2).csv')
data.dtypes
duplicates = data.duplicated()
duplicate_rows = data[data.duplicated()]
print(duplicate_rows)

data=data.drop_duplicates()
#outliers 
sns.boxplot(data['Economic Index'])
sns.boxplot(data['Industry Growth Rate (%)'])


winsor_iqr = Winsorizer(capping_method='iqr', 
                        tail='both', 
                        fold=1.5, 
                        variables=['Economic Index','Industry Growth Rate (%)'])

data[['Economic Index', 'Industry Growth Rate (%)']] = winsor_iqr.fit_transform(data[['Economic Index', 'Industry Growth Rate (%)']])

joblib.dump(winsor_iqr, 'winzor')

sns.boxplot(data['Economic Index'])
sns.boxplot(data['Industry Growth Rate (%)'])


#missing values
data['Economic Index'].isnull().sum()
data['Industry Growth Rate (%)'].isnull().sum()
data['Variant'].isna().sum()

stats.probplot(data['Economic Index'], dist="norm", plot=pylab)
data['Economic Index'].skew()
data['Economic Index']=np.log(data['Economic Index'])
stats.probplot(data['Economic Index'], dist="norm", plot=pylab)
data['Economic Index'].skew()

stats.probplot(data['Industry Growth Rate (%)'],dist='norm',plot=pylab)
data['Industry Growth Rate (%)'].skew()
data['Industry Growth Rate (%)'] = np.sqrt(data['Industry Growth Rate (%)'])
data['Industry Growth Rate (%)'].isna().sum()
stats.probplot(data['Industry Growth Rate (%)'], dist="norm", plot=plt)
data['Industry Growth Rate (%)'].skew()

mean_imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
data["Industry Growth Rate (%)"] = pd.DataFrame(mean_imputer.fit_transform(data[['Industry Growth Rate (%)']]))
data['Industry Growth Rate (%)'].isnull().sum()
joblib.dump(mean_imputer,'impute')

scale = StandardScaler()
data[['Economic Index', 'Industry Growth Rate (%)']]= scale.fit_transform(data[['Economic Index','Industry Growth Rate (%)']])
joblib.dump(scale,'scale')

data['Economic Index'].plot() # time series plot 
data['Industry Growth Rate (%)'].plot()

data.to_csv('data_final.csv', index=False)
from IPython.display import FileLink

# Provide a download link for the CSV file
FileLink('data_final.csv')
