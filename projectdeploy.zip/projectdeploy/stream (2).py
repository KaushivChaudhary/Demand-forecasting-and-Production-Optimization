# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 16:38:25 2024

@author: akshi
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from xgboost import XGBRegressor
from statsmodels.tsa.holtwinters import SimpleExpSmoothing
import pickle
import streamlit as st
from sklearn.ensemble import GradientBoostingRegressor
import warnings
warnings.filterwarnings('ignore')

# Load the data
data = pd.read_csv(r'C:\Users\varsh\Downloads\data_final.csv')

# Convert month to datetime for time series forecasting
data['Month'] = pd.to_datetime(data['Month'])

# Get dummies for 'Seasonality Factor'
data = pd.get_dummies(data, columns=['Seasonality Factor'], drop_first=True)

# Example list of variants you want to filter by
selected_variants_lr = ['XXX11', 'XXX15', 'XXX18','XXXV5','XXXV9']  # Replace with your desired variants
selected_variants_xgb=['XXX12','XXX13','XXX17']
selected_variants_se=['XXXV1','XXXV2','XXXV3','XXXV4']
var=['XXX11','XXX12','XXX13','XXX17', 'XXX15', 'XXX18','XXXV1','XXXV2','XXXV3','XXXV4','XXXV5','XXXV9']
# Filter the dataframe for these variants
filtered_data_lr = data[data['Variant'].isin(selected_variants_lr)]
filtered_data_xgb=data[data['Variant'].isin(selected_variants_xgb)]
filtered_data_se=data[data['Variant'].isin(selected_variants_se)]
# Display the filtered dataframe
print(filtered_data_lr)
print(filtered_data_xgb)
print(filtered_data_se)

variants_lr = filtered_data_lr['Variant'].unique()
variants_xgb=filtered_data_xgb['Variant'].unique()
variants_se=filtered_data_se['Variant'].unique()




# Train Linear Models for 5 variants
linear_models = {}

for variant_lr in filtered_data_lr['Variant']:
    variant_data_lr = filtered_data_lr[filtered_data_lr['Variant'] == variant_lr]
    
    X_variant_lr = variant_data_lr[['Economic Index', 'Seasonality Factor_Medium', 'Seasonality Factor_Low']]
    y_variant_lr = variant_data_lr['Industry Growth Rate (%)']
    
    X_lr_train, X_lr_test, y_lr_train, y_lr_test = train_test_split(X_variant_lr, y_variant_lr, test_size=0.2, shuffle=False)
    
    linear_model = LinearRegression()
    linear_model.fit(X_lr_train, y_lr_train)
    
   
    # Save the trained model
    linear_models[variant_lr] = linear_model
    pickle.dump(linear_model, open(f"linear_model.pkl", "wb"))

# Train XGBoost for 3 variants
xgb_models = {}

for variant_xgb in filtered_data_xgb['Variant']:
    variant_data_xgb=filtered_data_xgb[filtered_data_xgb['Variant']==variant_xgb]
    
    X_xgb_variant = variant_data_xgb[['Economic Index', 'Seasonality Factor_Medium', 'Seasonality Factor_Low']]
    y_xgb_variant = variant_data_xgb['Industry Growth Rate (%)']
    
    X_xgb_train, X_xgb_test, y_xgb_train, y_xgb_test = train_test_split(X_xgb_variant, y_xgb_variant, test_size=0.2, shuffle=False)
    
    xgb_model = XGBRegressor(objective='reg:squarederror',n_estimators=100, learning_rate=0.1)
    xgb_model.fit(X_xgb_train, y_xgb_train)
    
    # Save the trained model
    xgb_models[variant_xgb] = xgb_model
    pickle.dump(xgb_model, open(f"xgb_model.pkl", "wb"))
    
# Train Simple Exponential Smoothing (SES) for 4 variants
ses_models = {}

for variant_se in filtered_data_se['Variant']:
    variant_data_se = filtered_data_se[filtered_data_se['Variant'] == variant_se]
    
    # Only the 'Industry Growth Rate (%)' is used for SES
    y_se_variant = variant_data_se['Industry Growth Rate (%)']
    
    ses_model = SimpleExpSmoothing(y_se_variant).fit(smoothing_level=0.2, optimized=False)
    
    # Save the trained model
    ses_models[variant_se] = ses_model
    pickle.dump(ses_model, open(f"ses_model.pkl", "wb"))



se_models = {}
variants = data['Variant'].unique()

# Function to fit a Gradient Boosting model for each variant
for variant in variants:
    # Filter the dataframe for the current variant
    variant_df = data[data['Variant'] == variant]
    time_series = variant_df['Economic Index'].values
    # Split into train and test sets (e.g., last 20% for testing)
    split_idx = int(len(time_series) * 0.8)
    train, test = time_series[:split_idx], time_series[split_idx:] 
    # Fit Simple Exponential Smoothing (SES) model    
    se_model = SimpleExpSmoothing(y_se_variant).fit(smoothing_level=0.2, optimized=False)
    
    # Save the trained model
    se_models[variant] = se_model
    pickle.dump(se_model, open(f"se_model.pkl", "wb"))


# After training the models, save them using pickle

# Saving the XGBoost model
for variant, model in xgb_models.items():
    with open(f"xgb_model.pkl", 'wb') as f:
        pickle.dump(model, f)

# Saving the Linear Regression models
for variant, model in linear_models.items():
    with open(f"linear_model.pkl", 'wb') as f:
        pickle.dump(model, f)

# Saving the Simple Exponential Smoothing models
for variant, model in ses_models.items():
    with open(f"ses_model.pkl", 'wb') as f:
        pickle.dump(model, f)

for variant, model in se_models.items():
    with open(f"se_model.pkl", 'wb') as f:
        pickle.dump(model, f)
print("Models saved successfully.")