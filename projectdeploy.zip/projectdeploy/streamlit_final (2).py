# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 21:36:35 2024

@author: akshi
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from xgboost import XGBRegressor
from statsmodels.tsa.holtwinters import SimpleExpSmoothing
import pickle
import streamlit as st
import matplotlib.pyplot as plt
from scipy import stats
import joblib

# Load pre-trained models and scalers
modelxgb=pickle.load(open('xgb_model.pkl', 'rb'))
modelse=pickle.load(open('ses_model.pkl','rb'))
modellr=pickle.load(open('linear_model.pkl','rb'))
model=pickle.load(open('se_model.pkl','rb'))
impute=joblib.load('impute')
winzor=joblib.load('winzor')
minmax=joblib.load('scale')

def main():
    st.title("Time Series Forecasting with Confidence Intervals")
    st.sidebar.title("Forecasting")

    # File upload section
    uploadedFile = st.sidebar.file_uploader("Choose a file", type=['csv', 'xlsx'], accept_multiple_files=False, key="fileUploader")
    if uploadedFile is not None:
        try:
            data = pd.read_csv(uploadedFile, index_col=0)
        except:
            try:
                data = pd.read_excel(uploadedFile, index_col=0)
            except:
                st.error("The file format is not supported.")
                return
    else:
        st.sidebar.warning("Please upload a CSV or Excel file.")
        return
    
    
    # Data processing and transformation
    clean = pd.DataFrame(impute.transform(data), columns=data.columns)
    clean1 = pd.DataFrame(winzor.transform(clean), columns=data.columns)
    clean3 = pd.DataFrame(minmax.transform(clean1), columns=data.columns)
  
    # Get dummies for 'Seasonality Factor'
    data_f = pd.get_dummies(clean3, columns=['Seasonality Factor'], drop_first=True)
    feature_columns = ['Economic Index', 'Seasonality Factor_Low', 'Seasonality Factor_Medium', 'Month_Num', 'Year']  # Replace with actual columns used during training

# Check if all required columns are present
    missing_columns = [col for col in feature_columns if col not in data.columns]
    if missing_columns:
        st.error(f"Missing columns in the uploaded data: {', '.join(missing_columns)}")
    return

    # Example list of variants
    selected_variants_lr = ['XXX11', 'XXX15', 'XXX18', 'XXXV5', 'XXXV9']
    selected_variants_xgb = ['XXX12', 'XXX13', 'XXX17']
    selected_variants_se = ['XXXV1', 'XXXV2', 'XXXV3', 'XXXV4']

    # Ensure 'Variant' column exists and handle variant-based prediction
    if 'Variant' in data_f.columns:
        variant = data_f['Variant'].iloc[0]  # Assuming one variant per uploaded file

        # Predict based on variant
        if variant in selected_variants_lr:
            res = modellr.predict(data_f)
        elif variant in selected_variants_xgb:
            res = modelxgb.predict(data_f)
        elif variant in selected_variants_se:
            res = modelse.predict(data_f)
        else:
            st.error("Variant not found in model lists.")
            return
    else:
        st.error("Variant column is missing from the data.")
        return
# Use SES model for Economic Growth or other specific columns
    if 'Economic Growth' in data_f.columns:
        growth_forecast = se_model.predict(len(data_f))  # Assuming the SES model predicts the length of data
         # Add predictions to the dataframe
    else:
        st.warning("Economic Growth column is missing, skipping SES model prediction.")
    # Return the predictions or do further processing
    return res,growth_forecast

# Use Streamlit to display the predictions (this part will run inside a Streamlit app)
    
    # Display the results in Streamlit
    st.write("Model Prediction Results:", res)
    st.write("Data with Economic Growth Predictions:", growth_forecast)
    # Function to compute confidence intervals
    def compute_confidence_intervals(res,growth_forecast, stdev, confidence_level):
        z = stats.norm.ppf((1 + confidence_level) / 2)
        lower = res - z * stdev
        upper = res + z * stdev
        lower2=growth_forecast + z * stdev2
        upper2=growth_forecast - z*stdev2
        return lower, upper,lower2, upper2

    # Calculate standard deviation for the residuals
    stdev = np.std(data_f['Industry Growth Rate (%)'] - res)
    stdev2=np.std(data_f['Economic Index']-growth_forecast)
    # Calculate confidence intervals (90% and 95%)
    lower_90, upper_90 = compute_confidence_intervals(res, stdev, 0.90)
    lower_95, upper_95 = compute_confidence_intervals(res, stdev, 0.95)
    lower2_90, upper2_90 = compute_confidence_intervals(growth_forecast , stdev2, 0.90)
    lower2_95, upper2_95 = compute_confidence_intervals(growth_forecast , stdev2, 0.95)
    # Display predictions and confidence intervals
    results = pd.DataFrame({
        'Actual': data_f['Industry Growth Rate (%)'],
        'Actual2':dat['Economic Index'],
        'Predicted': res,
        'predicted2':growth_forecast,
        'Lower 90%': lower_90,
        'Upper 90%': upper_90,
        'Lower 95%': lower_95,
        'Upper 95%': upper_95,
        'Lower2 90%': lower2_90,
        'Upper2 90%': upper2_90,
        'Lower2 95%': lower2_95,
        'Upper2 95%': upper2_95        
    })
    
    st.subheader("Predictions vs Actual with Confidence Intervals")
    st.write(results)

    # Plot predictions and confidence intervals
    fig, ax = plt.subplots()
    ax.plot(data_f.index, data_f['Industry Growth Rate (%)'], label='Actual', color='blue')
    ax.plot(data_f.index, res, label='Predicted', color='red')

    # Plot confidence intervals
    ax.fill_between(data_f.index, lower_90, upper_90, color='orange', alpha=0.3, label='90% CI')
    ax.fill_between(data_f.index, lower_95, upper_95, color='green', alpha=0.2, label='95% CI')
    
    ax.legend()
    st.pyplot(fig)

    fig, ax = plt.subplots()
    ax.plot(data_f.index, data_f['Economic Index'], label='Actual', color='blue')
    ax.plot(data_f.index, growth_forecast , label='Predicted', color='red')

    # Plot confidence intervals
    ax.fill_between(data_f.index, lower2_90, upper2_90, color='orange', alpha=0.3, label='90% CI')
    ax.fill_between(data_f.index, lower2_95, uppe2r_95, color='green', alpha=0.2, label='95% CI')
    
    ax.legend()
    st.pyplot(fig)

if __name__ == '__main__':
    main()
